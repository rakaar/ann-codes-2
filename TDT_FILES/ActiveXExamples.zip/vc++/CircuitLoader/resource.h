//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CircuitLoader.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CIRCUITLOADER_DIALOG        102
#define IDR_MAINFRAME                   128
#define RADIO_RP2                       1000
#define RADIO_RA16                      1001
#define RADIO_RV8                       1002
#define RADIO_RL2                       1003
#define RADIO_USB                       1004
#define RADIO_GIGABIT                   1005
#define BUTTON_LOAD                     1006
#define BUTTON_CANCEL                   1007
#define IDC_COMMONDIALOG1               1008
#define RP2_1                           1009
#define RP2_2                           1010
#define RP2_3                           1011
#define RP2_4                           1012
#define RP2_5                           1013
#define RP2_6                           1014
#define RP2_7                           1015
#define RP2_8                           1016
#define RV8_1                           1017
#define RV8_2                           1018
#define RV8_3                           1019
#define RV8_4                           1020
#define RV8_5                           1021
#define RV8_6                           1022
#define RV8_7                           1023
#define RV8_8                           1024
#define EDIT_DEVNUM                     1025
#define STATUS_LABEL                    1026
#define RA16_1                          1041
#define RA16_2                          1042
#define RA16_3                          1043
#define RA16_4                          1044
#define RA16_5                          1045
#define RA16_6                          1046
#define RA16_7                          1047
#define RA16_8                          1048
#define RL2_1                           1049
#define RL2_2                           1050
#define RL2_3                           1051
#define RL2_4                           1052
#define RL2_5                           1053
#define RL2_6                           1054
#define RL2_7                           1055
#define RL2_8                           1056

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
